/*
    Adam Liszewski
    CS-210 Programming Languages
    Professor Gregori
    7-3 Project 3 Submission - Corner Grocery
    April 20, 2024
*/
// FileIO.cpp file containing code for reading inventory file and backing up map to file

#include "FileIO.h"
#include <fstream>
#include <iostream>
#include <sstream>

using namespace std;

namespace GroceryList {
    bool FileIO::readFile(const string& fileName, map<string, int>& data) {  // read each line of file and create map and count of items
        ifstream file(fileName);
        if (!file.is_open()) {
            cerr << "Error: Unable to open file: " << fileName << endl;
            return false;
        }

        string line;
        while (getline(file, line)) {  // read each line
            stringstream ss(line);
            string item;                // store string as item
            ss >> item;
            // Check if item exists in map
            auto it = data.find(item);
            if (it != data.end()) {
                // Item exists, increment count
                it->second++;
            }
            else {
                // Item doesn't exist, add to map with count 1
                data[item] = 1;
            }
        }
        file.close();
        return true;
    }

    bool FileIO::writeFile(const string& fileName, const map<string, int>& data) { // write map to file for backup overwrite each time
        ofstream outFile(fileName, ios::trunc); // Open file in truncate mode
        if (!outFile.is_open()) {
            cerr << "Error: Unable to create output file: " << fileName << endl;
            return false;
        }

        for (const auto& pair : data) {
            outFile << pair.first << " " << pair.second << endl;
        }
        outFile.close();
        return true;
    }
}

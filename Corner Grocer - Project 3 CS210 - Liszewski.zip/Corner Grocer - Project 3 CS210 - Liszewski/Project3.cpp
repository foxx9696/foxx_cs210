/*  
    Adam Liszewski
    CS-210 Programming Languages
    Professor Gregori 
    7-3 Project 3 Submission - Corner Grocery
    April 20, 2024
*/
// Project3.cpp Main project file containing menu and validation of input for menu
// Includes ItemCount to get the ItemCounter class


#include <iostream>
#include "ItemCounter.h" // ItemCounter to instantiate reading and mapping the input file as well as producing backup file

using namespace std;            // use the std namespace for input and output
using namespace GroceryList;    // use the GroceryList namespace defined in ItemCounter

int main() {
    ItemCounter counter;  // create an instance of the ItemCounter class

    int choice;
    do {
        cout << "Menu:\n";
        cout << "1. Get count of an item\n";
        cout << "2. Print item counts\n";
        cout << "3. Print histogram\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        // Input validation
        if (choice < 1 || choice > 4) {
            cout << "Invalid choice. Please enter a number between 1 and 4.\n";
            // Clear input buffer
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        switch (choice) {
        case 1: {
            counter.countItems();
            string item;
            cout << "Enter the item to find: ";
            cin >> item;
            cout << counter.getItemCount(item) << " " << item << endl;
            break;
        }
        case 2: {
            counter.countItems();
            counter.printItemCounts();
            break;
        }
        case 3: {
            counter.countItems();
            counter.printHistogram();
            break;
        }
        case 4: {
            cout << "Exiting program.\n";
            break;
        }
        }
    } while (choice != 4);

    return 0;
}

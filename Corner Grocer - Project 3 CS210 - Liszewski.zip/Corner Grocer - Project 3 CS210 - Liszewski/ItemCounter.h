/*
    Adam Liszewski
    CS-210 Programming Languages
    Professor Gregori
    7-3 Project 3 Submission - Corner Grocery
    April 20, 2024
*/
// ItemCounter.h file containing GroceryList namespace and ItemCounter class 
// Defines itemMap of items and count of items as well as defines the input and output files
// Public functions for counting items, printing items, and retrieving items and counts



#ifndef ITEMCOUNTER_H
#define ITEMCOUNTER_H

#include <string>
#include <map>

using namespace std;

namespace GroceryList {
    class ItemCounter {
    private:
        map<string, int> itemMap;    // Map of all items in the input file with counts
        string inventoryFile = "CS210_Project_Three_Input_File.txt";  // Original input file
        string frequencyFile = "frequency.dat";  // output file for backup

    public:
        ItemCounter();      
        void countItems();      // function to count items 
        void readInventory();   // read inventory file
        void saveDataToFile();  // save data to file
        void updateFrequencyFile(); // Function to update frequency.dat
        int getItemCount(const string& item); // get the counts of an item
        void printItemCounts(); // print the item counts
        void printHistogram();  // print the histogram
    };
}

#endif

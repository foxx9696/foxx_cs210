/*
    Adam Liszewski
    CS-210 Programming Languages
    Professor Gregori
    7-3 Project 3 Submission - Corner Grocery
    April 20, 2024
*/
// ItemCounter.cpp file containing code for GroceryList namespace and ItemCounter class 
// Code for the functions of counting items, printing items, and retrieving items and counts

#include "ItemCounter.h"
#include "FileIO.h"
#include <iostream>
#include <algorithm> // for std::transform

using namespace std;

namespace GroceryList {

    ItemCounter::ItemCounter() {} // ItemCounter Class

    void ItemCounter::countItems() {            // create the itemMap
        itemMap.clear();    // Clear the map before reading the file to avoid counts not representing true inventory
        readInventory();
        updateFrequencyFile();
    }

    void ItemCounter::readInventory() {         // open and read the inventory file
        if (!FileIO::readFile(inventoryFile, itemMap)) {
            cerr << "Error: Unable to open inventory file." << endl;
        }
    }

    void ItemCounter::saveDataToFile() {        // save data to file
        if (!FileIO::writeFile(frequencyFile, itemMap)) {
            cerr << "Error: Unable to save data to frequency file." << endl;
        }
    }

    void ItemCounter::updateFrequencyFile() {   // update the frequency file (calls saveDataToFile)
        saveDataToFile();
    }

    int ItemCounter::getItemCount(const string& item) { // retrieve the itemCount for an item
        return itemMap[item];
    }

    void ItemCounter::printItemCounts() {   // print all items and their count
        for (const auto& pair : itemMap) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    void ItemCounter::printHistogram() {  // print item and count represented as a histogram
        for (const auto& pair : itemMap) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
    }
}

/*
    Adam Liszewski
    CS-210 Programming Languages
    Professor Gregori
    7-3 Project 3 Submission - Corner Grocery
    April 20, 2024
*/
// FileIO.h file containing class for reading inventory file and creating map as well as
// writing map to a backup file

#ifndef FILEIO_H
#define FILEIO_H

#include <string>
#include <map>

using namespace std;

namespace GroceryList {
    class FileIO {
    public:
        static bool readFile(const string& fileName, map<string, int>& data);   // read a file into a map
        static bool writeFile(const string& fileName, const map<string, int>& data); // output map to a file for backup
    };
}

#endif

// 
//  Adam Liszewski
//  SNHU CS-210 
//  3-3 Project One Suubmission 
//
// Clock.cpp file - reusable code for clock, no screen output

#include "Clock.h" // include the Clock header file

unsigned int hour; // create hour variable
unsigned int minute; // create minute variable
unsigned int second; // create second variable

void setTime(unsigned int h, unsigned int m, unsigned int s) // set the clock time in hours, minutes, seconds
{
	hour = h;
	minute = m;
	second = s;
}

unsigned int getHours() // get the hour parameter
{
	return hour;
}

void setHours(unsigned int h) // set the hour parameter
{
	// check if h is in range
	if (h >= 0 && h <= 23) {
		hour = h;
	}
	else {
		hour = 12; //default to 12 if invalid h sent
	}
}

void addOneHour() // Adds one hour to the clock
{
	/*	 
	* if getHour() is between 0 and 22 inclusive, add 1 and setHour() to that
	* if getHour() is 23 the next value for hour is 0 so setHour() to that
	* test will check values of hours from 0 to 23 from getHour()
	*/
	if (getHours() >= 0 && getHours() < 23) {
		setHours(getHours() + 1);
	}
	else if (getHours() == 23) {
		setHours(0);
	}
}

void addOneMinute() // Adds one minute to the clock
{
	/*	 
	* if getMinutes() is between 0 and 58 inclusive, add 1 and setMinutes() to that
	* if getMinutes() is 59 the next value for minute is 0 so setMinutes() to that and increment hour
	* test will check values of hours from 0 to 59 from getMinutes()
	*/
	if (getMinutes() >= 0 && getMinutes() < 59) {
		setMinutes(getMinutes() + 1);
	}
	else if (getMinutes() == 59) {
		setMinutes(0);
		addOneHour();
	}
}

unsigned int getMinutes() // return number of minutes
{
	return minute;
}

void setMinutes(unsigned int m) //set the minutes
{
	// check if m is in range of 0 to 59 inclusive
	if (m >= 0 && m <= 59) {
		minute = m;
	}
	else {
		minute = 0; //default to 0 if invalid m sent
	}
}

void addOneSecond() // Add one second to the clock
{
	/*	 
	* if getSeconds() is between 0 and 58 inclusive, add 1 and setSeconds() to that
	* if getSeconds() is 59 the next value for minute is 0 so setSeconds() to that and increment minutes
	* test will check values of hours from 0 to 59 from getSeconds()
	*/	
	if (getSeconds() >= 0 && getSeconds() < 59) {
		setSeconds(getSeconds() + 1);
	}
	else if (getSeconds() == 59) {
		setSeconds(0);
		addOneMinute();
	}
}

unsigned int getSeconds() // return number of seconds
{
	return second;
}

void setSeconds(unsigned int s)
{
	// verify s is in range
	if (s >= 0 && s <= 59) {
		second = s;
	}
	else {
		second = 0; //default to 0 if invalid s sent
	}
}

string twoDigitString(unsigned int n)
{
	/**
	* Formats a number as 2 digits, with a leading 0 if needed
	* This method can be useful when converting a time like 9 hours, 12 minutes and 3 seconds to "09:12:03"
	*
	* @param n number to format, assumed between 0 and 59, inclusive
	* @return two digit string representation of number
	*/

	// Numbers between 10 and 59 just need to be converted to a string
	// Numbers from 0 to 9 need a "O" tacked onto the front of the string representation of the number
	// Return the two digit string representation of n

	string result = "";
	result = to_string(n);

	if (n >= 0 && n <= 9) {
		result = "0" + result;
	}
	return result;
}

string formatTime12(unsigned int h, unsigned int m, unsigned int s)
{
	/**
	* Formats the time in am/pm format
	*
	* @param h, hours 0 to 23
	* @param m, minutes 0 to 59
	* @param s, seconds 0 to 59
	*
	* @return hh:mm:ss A M or hh:mm:ss P M where hh is between 01 and 12, inclusive
	*/

	// if hour == 12, return 12, otherwise return mod of hours and 12
	string hours = twoDigitString(h % 12 == 0 ? 12 : h % 12);

	// Format the time string
	return hours + ":" + twoDigitString(m) + ":" + twoDigitString(s) + (h < 12 ? " A M" : " P M"); 
}

string formatTime24(unsigned int h, unsigned int m, unsigned int s)
{
	/**
	* Formats the time in military format
	*
	* @param h, hours 0 to 23
	* @param m, minutes 0 to 59
	* @param s, seconds 0 to 59
	*
	* @return hh:mm:ss
	*/
	return twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s);
}

string nCharString(size_t n, char c)
{
	/**
	 * Returns a string of length n, each character a c.
	 * For example, nCharString(5, '*') should return "*****"
	 *
	 * @param n string length, >=0
	 * @return string of n c's
	 */
	if (n == 0) {

		return "";

	}
	return string(1, c) + nCharString(n - 1, c);
}

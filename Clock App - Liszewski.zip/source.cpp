// 
//  Adam Liszewski
//  SNHU CS-210 
//  3-3 Project One Suubmission 
//
// source.cpp file - contains main program functions


#include <iostream>
#include <iomanip>
#include <string>
#include "Clock.h"

const string menu[4] = { "Add One Hour", "Add One Minute", "Add One Second", "Exit Program" }; // pre-populate menu string
const unsigned int WIDTH = 57; // set menu width
const unsigned int NUM_MENU_ITEMS = 4;

void displayClocks(unsigned int h, unsigned int m, unsigned int s) {
	/**
	* Display the clocks
	*
	* @param h, hours 0 to 23
	* @param m, minutes 0 to 59
	* @param s, seconds 0 to 59
	*/
	// nCharString(27,'*') gives a string of 27 stars. nCharString(3,' ') gives 3 spaces
	// formatTime12(h, m, s) and formatTime24(h, m, s) give the formatted time as specified in the assignment	
	// test will pass in (0, 59, 9)
	// 
	// 27 stars + 3 spaces + 27 stars + endl
	cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
	// 1 star + 6 spaces + 12-HOUR CLOCK + 6 spaces + 1 star + 3 spaces
	cout << "*" << nCharString(6, ' ') << "12-HOUR CLOCK" << nCharString(6, ' ') << "*   ";
	// 1 star + 6 spaces + 24-HOUR CLOCK + 6 spaces + 1 star + endl
	cout << "*" << nCharString(6, ' ') << "24-HOUR CLOCK" << nCharString(6, ' ') << "*" << endl;
	// blank line
	cout << endl;
	// 1 star + 6 spaces + formatTime12(h, m, s) + 7 spaces + 1 star + 3 spaces
	cout << "*" << nCharString(6, ' ') << formatTime12(h, m, s) << nCharString(7, ' ') << "*   ";
	// 1 star + 8 spaces + formatTime24(h, m, s) + 9 spaces + 1 star + endl
	cout << "*" << nCharString(8, ' ') << formatTime24(h, m, s) << nCharString(9, ' ') << "*" << endl;
	// 27 stars + 3 spaces + 27 stars + endl
	cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
}

void printMenu(const string strings[], unsigned int numStrings, unsigned int width) {
	/**
	 * Prints menu
	 *
	 * @param *strings[], nonempty array of choices
	 * @param width, width of each line, will be comfortably bigger than the longest string
	 *
	 */
	 // first print width *'s followed by an endl
	const int borderSize = 7; // "* # -  "
	cout << nCharString(width, '*') << endl;
	/** Next, for each string s in the array:
	 * cout a star, a space, the item Number a space a hyphen another space, s,
	 * and enough spaces to get to a length of width - 1 (enough will depend on the length of the current menu item).
	 * Close the line with a star and an endl. The goal is that the stars on the right align with each other and each line
	 * has the same width, passed in as a parameter.
	 * (Hint: calculate the needed number of spaces and use nCharString to produce them)
	 * Skip a line after each line except the last line
	 */
	for (unsigned int i = 0; i < numStrings; ++i) {
		unsigned int numSpaces = width - borderSize - int(strings[i].length());
		cout << "* " << i + 1 << " - " << strings[i] << nCharString(numSpaces, ' ') << "*" << endl;
		if (i < numStrings - 1) {
			cout << endl;
		}
	}
	// outside the loop print another width *s followed by an endl
	cout << nCharString(width, '*') << endl;
}


unsigned int getMenuChoice(unsigned int maxChoice) {
	/**
	* Gets menu choice 1 through maxChoice, inclusive
	*
	* @param maxChoice, maximum choice index, a number between 2 and 9, inclusive
	* @return the first legal choice input, could be 1 through maxChoice, inclusive
	*/	
	unsigned int choice;
	bool validInput = false;

	while (!validInput) {
		// cout << "Enter a number between 1 and " << maxChoice << ": ";
		// Try to extract an integer from input
		cin >> choice;
		if (choice >= 1 && choice <= maxChoice) {
			// Check if choice is within range
			validInput = true;
		}
		else {
			cout << "Invalid input please Enter a number between 1 and " << maxChoice << endl;
		}
	}
	return choice;   // return the value
}

void mainMenu() {
	/**
	 * repeats getting the user's choice and taking the appropriate action until the user chooses 4 for exit
	 */
	int choice;
	// Loop until the user chooses exit (4)
	do {
		// Get the user's choice using getMenuChoice(4)
		displayClocks(getHours(), getMinutes(), getSeconds());				
		printMenu(menu, NUM_MENU_ITEMS, WIDTH);
		choice = getMenuChoice(4);
		// Take action based on the user's choice
		switch (choice) {

		case 1:
			addOneHour();
			break;
		case 2:
			addOneMinute();
			break;
		case 3:
			addOneSecond();
			break;
		case 4:
			cout << "Good Bye" << endl; // say good bye
			break;
		default:
			// Handle invalid input (shouldn't happen with getMenuChoice(4))
			break;
		}
	} while (choice != 4); // Repeat until choice is 4 (exit)  
	// nothing to return, just call the appropriate methods
}

int main() {
	//Set the time
	setTime(12, 59, 59);
	//displayClocks(getHours(), getMinutes(), getSeconds());
	//printMenu(menu, NUM_MENU_ITEMS, WIDTH);
	mainMenu();
	//Follow the flow chart
	//Print menu
	//Get user choice
	//Handle the user choice
	//Display updated clock
	//error message invalid output

	//print good bye on exit

	return 0;
}
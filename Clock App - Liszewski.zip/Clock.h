// 
//  Adam Liszewski
//  SNHU CS-210 
//  3-3 Project One Suubmission 
//
// clock.h - header file for all functions contained in Clock.cpp

#ifndef ADD_H_INCLUDED
#define ADD_H_INCLUDED
#include <string>
using namespace std;

void setTime(unsigned int, unsigned int, unsigned int); // set the time on the clock
unsigned int getHours(); // get the hours
void setHours(unsigned int); // set the hours
void addOneHour(); // add an hour to the clock
void addOneMinute(); // add a minute to the clock
unsigned int getMinutes(); // get the minutes
void setMinutes(unsigned int); // set the minutes
void addOneSecond(); // add a second to the clock
unsigned int getSeconds(); // get the seconds
void setSeconds(unsigned int); // set the seconds

string formatTime12(unsigned int, unsigned int, unsigned int); // Format time am/pm
string formatTime24(unsigned int, unsigned int, unsigned int); // Format military time

string twoDigitString(unsigned int); // convert string to 2 digits - "9" becomes "09"
string nCharString(size_t, char); // repeat character a number of times (5,'*') is "*****"

#endif
